#-*- coding:utf-8 -*-
from host_tweak_ui import HostTweakUI

"""
host切换工具
@author: thebye85
@date: 2013-06-06
"""
if(__name__ == "__main__"):
    HostTweakUI()
